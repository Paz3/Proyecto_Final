<footer>
	<div class="container">
		<div class="container-fluid">
			<div class="row">
				<div class="footer__elements">
					<div class="footer__elements--icon"><a href="assets/download/CV_PRS.pdf" target="_blank">CV <i class="fas fa-arrow-circle-down"></i></a></div>
				</div>
			</div>
		</div>
	</div>
</footer>


<?php wp_footer() ?>
</body>
</html>
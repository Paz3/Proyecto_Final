<?php

    function the_theme_file_uri($file) {
        echo get_theme_file_uri($file);
    }
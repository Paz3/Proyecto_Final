jQuery(document).ready( function($) {

	// Functions

});
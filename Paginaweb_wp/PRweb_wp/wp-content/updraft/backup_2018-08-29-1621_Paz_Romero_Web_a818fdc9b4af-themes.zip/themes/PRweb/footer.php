<footer>
	<div class="container">
		<div class="container-fluid">
			<div class="row">
				<div class="footer__elements">
					<div class="footer__elements--icon"><a href="http://186.64.118.50/~feg7mpaz/wp-content/uploads/2018/08/CV_PRS.pdf" target="_blank">CV <i class="fas fa-arrow-circle-down"></i></a></div>
				</div>
			</div>
		</div>
	</div>
</footer>


<?php wp_footer() ?>
</body>
</html>
<?php get_header() ?>
	<?php the_post() ?>
	
	<?php the_post_thumbnail() ?>
	<?php the_title() ?>
	<?php //the_content(); ?>

	<main>
	<div class="container">
		<div class="container-fluid">
			<div class="row">

				<h1>¿Nos vemos? <i class="far fa-eye"></i></h1>
				<p>Nada mejor que expresar una idea de manera presencial, si quieres nos reunimos en un punto central para que me cuentes tu idea.</p>
				
			</div>
		</div>
	</div>

<div class="container">
	<div class="container-fluid">
		<div class="row">
			<div class="form-area">  
				<form role="form">
					<br>
						<h3>Ubicación</h3>
						<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d26635.597032888498!2d-70.6355924082425!3d-33.43735921408251!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9662c584af338189%3A0x50b29eed192c40cb!2sStarbucks+Coffee!5e0!3m2!1ses-419!2scl!4v1534468228404" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
				</form>
			</div>
	    </div>
    </div>
</div>


</main>

<?php get_footer() ?>
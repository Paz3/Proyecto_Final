<?php if ( is_active_sidebar( 'sidebar_widget' ) ) { ?>
    <?php dynamic_sidebar( 'sidebar_widget' ); ?>
<?php }; ?>